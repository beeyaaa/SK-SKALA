package com.skala.skala_shop_api.data.dto;

import java.util.List;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// 모든 필드의 getter와 setter를 자동 생성
@Getter
@Setter
// DTO 객체를 생성할 때 사용할 기본 생성자를 자동 생성
@NoArgsConstructor

public class OrderListDto {

    private String customerId;
    private Double customerPoint;
    private List<OrderItemDto> products;

    @Builder
    public OrderListDto(
            String customerId, 
            Double customerPoint,
            List<OrderItemDto> products) {
        this.customerId = customerId;
        this.customerPoint = customerPoint;
        this.products = products;
    }
}
