package com.skala.skala_shop_api.data.table;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "customer")
@Getter
@Setter
@NoArgsConstructor // JPA에서 엔터티를 생성할 때 필요한 기본 생성자를 자동 생성
public class Customer {
    @Id // 고객이 직접 사용하는 문자열 ID를 기본 키로 지정
    @Schema(description = "고객 ID", example = "skala01")
    @NotBlank(message = "고객 ID는 필수입니다.")
    private String customerId;

    @Schema(description = "고객 비밀번호", example = "pw1234", accessMode = Schema.AccessMode.WRITE_ONLY)
    @NotBlank(message = "고객 비밀번호는 필수입니다.")
    private String customerPassword;

    @Schema(description = "고객 보유 포인트", example = "1000000")
    private Double customerPoint;

    public Customer(String customerId, Double customerPoint) {
        this.customerId = customerId;
        this.customerPoint = customerPoint;
    }
}
