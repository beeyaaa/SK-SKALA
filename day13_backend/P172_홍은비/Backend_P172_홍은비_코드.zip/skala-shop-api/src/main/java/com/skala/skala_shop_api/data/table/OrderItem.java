package com.skala.skala_shop_api.data.table;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity // DB 테이블과 연결되는 클래스임을 명시
@Table(name = "order_item") // order_item 테이블과 연결
@Getter
@Setter
@NoArgsConstructor // JPA에서 엔터티를 생성할 때 필요한 기본 생성자를 자동 생성
public class OrderItem {
    @Id // 이 필드를 테이블의 기본 키로 지정
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 기본 키 값을 데이터베이스의 자동 증가 방식으로 생성
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY) // 다수의 주문된 상품이 하나의 고객을 참조
    @JoinColumn(name = "customer_id") // Customer 테이블의 기본 키를 참조하는 외래 키
    //orderitem(many) -> customer(one)
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY) // 다수의 주문된 상품이 하나의 상품을 참조
    @JoinColumn(name = "product_id") // Product 테이블의 기본 키를 참조하는 외래 키
    //orderitem(many) -> product(one)
    private Product product;

    private Integer quantity;

    public OrderItem(Customer customer, Product product, Integer quantity) {
        this.customer = customer;
        this.product = product;
        this.quantity = quantity;
    }
}
