package com.skala.skala_shop_api.data.table;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


//JPA: Java 객체를 DB 테이블과 연결해주는 표준 규칙
@Getter //getter 메서드 자동 생성
@Setter //setter 메서드 자동 생성
@NoArgsConstructor //생성자 자동 생성
@Entity //JPA에서 관리하는 엔터티임을 표시
@Table(name = "product") //이 엔터티와 연결할 데이터베이스 테이블 이름을 product로 지정

public class Product {

    
    @Id //이 필드를 테이블의 기본 키로 지정
    @GeneratedValue(strategy = GenerationType.IDENTITY) //기본 키 값을 데이터베이스의 자동 증가 방식으로 생성
    @Schema(description = "상품 ID", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @Schema(description = "상품명", example = "오버핏 블레이저")
    @NotBlank(message = "상품명은 필수입니다.")
    private String productName;

    @Schema(description = "상품 가격", example = "129000")
    @NotNull(message = "상품 가격은 필수입니다.")
    @Positive(message = "상품 가격은 0보다 커야 합니다.")
    private Double productPrice;

    public Product(String productName, Double productPrice) {
        this.productName = productName;
        this.productPrice = productPrice;
    }
}
