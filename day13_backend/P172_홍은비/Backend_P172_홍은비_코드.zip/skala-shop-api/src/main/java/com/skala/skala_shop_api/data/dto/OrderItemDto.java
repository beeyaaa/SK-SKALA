package com.skala.skala_shop_api.data.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// 모든 필드의 getter와 setter를 자동 생성
@Getter
@Setter
// DTO 객체를 생성할 때 사용할 기본 생성자를 자동 생성
@NoArgsConstructor
public class OrderItemDto {

    private Long productId;
    private String productName;
    private Double productPrice;
    private Integer quantity;

    // 각 필드의 값을 메서드 체이닝 방식으로 설정할 수 있는 Builder를 생성
    @Builder
    public OrderItemDto(
            Long productId,
            String productName,
            Double productPrice,
            Integer quantity) {
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.quantity = quantity;
    }
}
