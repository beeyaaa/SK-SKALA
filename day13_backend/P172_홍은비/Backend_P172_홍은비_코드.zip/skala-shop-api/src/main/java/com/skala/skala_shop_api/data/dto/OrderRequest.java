package com.skala.skala_shop_api.data.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// 주문·취소 요청 JSON의 값을 읽고 설정할 getter와 setter를 자동 생성
@Getter
@Setter
// Spring이 요청 JSON을 객체로 변환할 때 사용할 기본 생성자를 자동 생성
@NoArgsConstructor
public class OrderRequest {

    @Schema(description = "주문하거나 취소할 상품 ID", example = "1")
    @NotNull(message = "상품 ID는 필수입니다.")
    @Positive(message = "상품 ID는 1 이상이어야 합니다.")
    private Long productId;

    @Schema(description = "주문하거나 취소할 수량", example = "2")
    @NotNull(message = "수량은 필수입니다.")
    @Positive(message = "수량은 1 이상이어야 합니다.")
    private Integer quantity;
}
