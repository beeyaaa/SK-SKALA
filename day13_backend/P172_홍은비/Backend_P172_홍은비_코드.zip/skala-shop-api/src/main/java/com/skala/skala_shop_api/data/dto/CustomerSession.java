package com.skala.skala_shop_api.data.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// 로그인 요청 JSON의 값을 읽고 설정할 getter와 setter를 자동 생성
@Getter
@Setter
// Spring이 요청 JSON을 객체로 변환할 때 사용할 기본 생성자를 자동 생성
@NoArgsConstructor
public class CustomerSession {

    @Schema(description = "고객 ID", example = "skala01")
    @NotBlank(message = "고객 ID는 필수입니다.")
    private String customerId;

    @Schema(description = "고객 비밀번호", example = "pw1234")
    @NotBlank(message = "고객 비밀번호는 필수입니다.")
    private String customerPassword;
}
